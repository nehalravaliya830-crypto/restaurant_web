<?php
session_start();
$_SESSION['payment_method'] = "Paytm";
$_SESSION['payment_status'] = "done";

if(isset($_POST['pay_paytm'])){
   header("Location: success.php");
   exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Paytm Payment - ByteBuzz Checkout</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <style>
      body{display:flex;justify-content:center;align-items:center;min-height:100vh;background:#000;font-family:Arial, sans-serif;margin:0;padding:15px;}
      .payment-box{background:#fff;padding:40px;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,0.2);width:100%;max-width:500px;text-align:center;}
      .payment-box h1{margin-bottom:20px;color:#000;font-size:24px;}
      .box{width:100%;padding:12px;margin:10px 0;border:1px solid #767676;border-radius:6px;box-sizing:border-box;font-size:16px;}
      .box:focus-visible{outline:3px solid #000;outline-offset:2px;}
      .btn{width:100%;padding:14px;background:#fbc02d;color:#000;font-weight:bold;border:none;border-radius:8px;cursor:pointer;transition:0.3s;font-size:16px;margin-top:10px;}
      .btn:hover{background:#e6ac00;}
      .btn:focus-visible{outline:3px solid #000;outline-offset:2px;}
      .sr-only{position:absolute!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;border:0!important;}
      .skip-link{position:absolute;top:-100px;left:15px;background:#fff;color:#000;padding:10px 15px;font-weight:bold;text-decoration:none;z-index:100;}
      .skip-link:focus{top:15px;outline:3px solid #fbc02d;}
   </style>
</head>
<body>
   <a href="#payment-main" class="skip-link">Skip to payment</a>
   <main id="payment-main" class="payment-box">
      <h1><i class="fas fa-mobile-alt" aria-hidden="true"></i> Pay via Paytm</h1>
      <form method="post" autocomplete="on">
         <label for="paytm-mobile" class="sr-only">10 Digit Paytm Registered Mobile Number</label>
         <input type="tel" id="paytm-mobile" name="mobile" placeholder="Paytm Mobile Number" class="box" pattern="\d{10}" maxlength="10" required autocomplete="tel" aria-required="true">
         <input type="submit" name="pay_paytm" value="Pay Now" class="btn">
      </form>
   </main>
</body>
</html>
