<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/add_cart.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Search Dishes - ByteBuzz</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->
<?php include 'components/user_header.php'; ?>
<!-- header section ends -->

<main id="main-content">

   <h1 class="sr-only">Search ByteBuzz Dishes</h1>

   <!-- search form section starts  -->

   <section class="search-form" aria-label="Search Form">
      <form method="post" action="" role="search">
         <label for="search-input" class="sr-only">Search for food or dishes</label>
         <input type="text" id="search-input" name="search_box" placeholder="search here..." class="box" value="<?= htmlspecialchars($_POST['search_box'] ?? ''); ?>">
         <button type="submit" name="search_btn" class="fas fa-search" aria-label="Submit search"><span class="sr-only">Search</span></button>
      </form>
   </section>

   <!-- search form section ends -->

   <section class="products" style="min-height: 80vh; padding-top:0;" aria-label="Search Results">

   <div class="box-container">

         <?php
            if(isset($_POST['search_box']) OR isset($_POST['search_btn'])){
            $search_box = $_POST['search_box'];
            $select_products = $conn->prepare("SELECT * FROM `products` WHERE name LIKE ?");
            $select_products->execute(["%{$search_box}%"]);
            if($select_products->rowCount() > 0){
               while($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)){
         ?>
         <form action="" method="post" class="box">
            <input type="hidden" name="pid" value="<?= $fetch_products['id']; ?>">
            <input type="hidden" name="name" value="<?= htmlspecialchars($fetch_products['name']); ?>">
            <input type="hidden" name="price" value="<?= $fetch_products['price']; ?>">
            <input type="hidden" name="image" value="<?= htmlspecialchars($fetch_products['image']); ?>">
            <a href="quick_view.php?pid=<?= $fetch_products['id']; ?>" class="fas fa-eye" aria-label="Quick view <?= htmlspecialchars($fetch_products['name']); ?>"><span class="sr-only">Quick view <?= htmlspecialchars($fetch_products['name']); ?></span></a>
            <button type="submit" class="fas fa-shopping-cart" name="add_to_cart" aria-label="Add <?= htmlspecialchars($fetch_products['name']); ?> to cart"><span class="sr-only">Add to cart</span></button>
            <img src="uploaded_img/<?= htmlspecialchars($fetch_products['image']); ?>" alt="<?= htmlspecialchars($fetch_products['name']); ?>">
            <a href="category.php?category=<?= urlencode($fetch_products['category']); ?>" class="cat"><?= htmlspecialchars($fetch_products['category']); ?></a>
            <div class="name"><?= htmlspecialchars($fetch_products['name']); ?></div>
            <div class="flex">
               <div class="price"><span>₹</span><?= $fetch_products['price']; ?></div>
               <label class="sr-only" for="search-qty-<?= $fetch_products['id']; ?>">Quantity for <?= htmlspecialchars($fetch_products['name']); ?></label>
               <input type="number" id="search-qty-<?= $fetch_products['id']; ?>" name="qty" class="qty" min="1" max="99" value="1" maxlength="2" aria-label="Quantity for <?= htmlspecialchars($fetch_products['name']); ?>">
            </div>
         </form>
         <?php
               }
            }else{
               echo '<p class="empty" role="status">no products matched your search!</p>';
            }
         }
         ?>

      </div>

   </section>

</main>

<!-- footer section starts  -->
<?php include 'components/footer.php'; ?>
<!-- footer section ends -->

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>