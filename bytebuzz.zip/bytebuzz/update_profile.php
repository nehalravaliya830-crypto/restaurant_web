<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:home.php');
   exit;
};

if(isset($_POST['submit'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);

   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING);

   if(!empty($name)){
      $update_name = $conn->prepare("UPDATE `users` SET name = ? WHERE id = ?");
      $update_name->execute([$name, $user_id]);
   }

   if(!empty($email)){
      $select_email = $conn->prepare("SELECT * FROM `users` WHERE email = ? AND id != ?");
      $select_email->execute([$email, $user_id]);
      if($select_email->rowCount() > 0){
         $message[] = 'email already taken!';
      }else{
         $update_email = $conn->prepare("UPDATE `users` SET email = ? WHERE id = ?");
         $update_email->execute([$email, $user_id]);
      }
   }

   if(!empty($number)){
      $select_number = $conn->prepare("SELECT * FROM `users` WHERE number = ? AND id != ?");
      $select_number->execute([$number, $user_id]);
      if($select_number->rowCount() > 0){
         $message[] = 'number already taken!';
      }else{
         $update_number = $conn->prepare("UPDATE `users` SET number = ? WHERE id = ?");
         $update_number->execute([$number, $user_id]);
      }
   }
   
   $empty_pass = 'da39a3ee5e6b4b0d3255bfef95601890afd80709';
   $select_prev_pass = $conn->prepare("SELECT password FROM `users` WHERE id = ?");
   $select_prev_pass->execute([$user_id]);
   $fetch_prev_pass = $select_prev_pass->fetch(PDO::FETCH_ASSOC);
   $prev_pass = $fetch_prev_pass['password'];
   $old_pass = sha1($_POST['old_pass']);
   $old_pass = filter_var($old_pass, FILTER_SANITIZE_STRING);
   $new_pass = sha1($_POST['new_pass']);
   $new_pass = filter_var($new_pass, FILTER_SANITIZE_STRING);
   $confirm_pass = sha1($_POST['confirm_pass']);
   $confirm_pass = filter_var($confirm_pass, FILTER_SANITIZE_STRING);

   if($old_pass != $empty_pass){
      if($old_pass != $prev_pass){
         $message[] = 'old password not matched!';
      }elseif($new_pass != $confirm_pass){
         $message[] = 'confirm password not matched!';
      }else{
         if($new_pass != $empty_pass){
            $update_pass = $conn->prepare("UPDATE `users` SET password = ? WHERE id = ?");
            $update_pass->execute([$confirm_pass, $user_id]);
            $message[] = 'password updated successfully!';
         }else{
            $message[] = 'please enter a new password!';
         }
      }
   }  

}

$select_profile = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
$select_profile->execute([$user_id]);
$fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Update Profile - ByteBuzz</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->
<?php include 'components/user_header.php'; ?>
<!-- header section ends -->

<main id="main-content">

   <h1 class="sr-only">Update Profile Settings</h1>

   <section class="form-container update-form">

      <form action="" method="post" aria-labelledby="update-profile-heading">
         <h2 id="update-profile-heading" style="font-size:2.5rem; text-transform:uppercase; margin-bottom:1rem; color:var(--black);">update profile</h2>
         
         <label for="up-name" class="sr-only">Update Full Name</label>
         <input type="text" id="up-name" name="name" placeholder="<?= htmlspecialchars($fetch_profile['name'] ?? 'enter your name'); ?>" class="box" maxlength="50" autocomplete="name">
         
         <label for="up-email" class="sr-only">Update Email Address</label>
         <input type="email" id="up-email" name="email" placeholder="<?= htmlspecialchars($fetch_profile['email'] ?? 'enter your email'); ?>" class="box" maxlength="50" autocomplete="email" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <label for="up-number" class="sr-only">Update Mobile Number</label>
         <input type="tel" id="up-number" name="number" placeholder="<?= htmlspecialchars($fetch_profile['number'] ?? 'enter your number'); ?>" class="box" pattern="[0-9]{10}" maxlength="10" autocomplete="tel">
         
         <label for="up-old-pass" class="sr-only">Current Password</label>
         <input type="password" id="up-old-pass" name="old_pass" placeholder="enter your old password" class="box" maxlength="50" autocomplete="current-password" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <label for="up-new-pass" class="sr-only">New Password</label>
         <input type="password" id="up-new-pass" name="new_pass" placeholder="enter your new password" class="box" maxlength="50" autocomplete="new-password" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <label for="up-confirm-pass" class="sr-only">Confirm New Password</label>
         <input type="password" id="up-confirm-pass" name="confirm_pass" placeholder="confirm your new password" class="box" maxlength="50" autocomplete="new-password" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <input type="submit" value="update now" name="submit" class="btn">
      </form>

   </section>

</main>

<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>