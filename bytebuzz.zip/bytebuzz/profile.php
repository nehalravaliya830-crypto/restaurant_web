<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:home.php');
   exit;
};

$select_profile = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
$select_profile->execute([$user_id]);
$fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Your Profile - ByteBuzz</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->
<?php include 'components/user_header.php'; ?>
<!-- header section ends -->

<main id="main-content">

   <h1 class="sr-only">Your Account Profile</h1>

   <section class="user-details" aria-label="Account Details">

      <div class="user">
         <img src="images/user-icon.png" alt="" aria-hidden="true">
         <p><i class="fas fa-user" aria-hidden="true"></i><span><?= htmlspecialchars($fetch_profile['name'] ?? ''); ?></span></p>
         <p><i class="fas fa-phone" aria-hidden="true"></i><span><?= htmlspecialchars($fetch_profile['number'] ?? ''); ?></span></p>
         <p><i class="fas fa-envelope" aria-hidden="true"></i><span><?= htmlspecialchars($fetch_profile['email'] ?? ''); ?></span></p>
         <a href="update_profile.php" class="btn" aria-label="Update your contact details">update info</a>
         <p class="address"><i class="fas fa-map-marker-alt" aria-hidden="true"></i><span><?php if(empty($fetch_profile['address'])){echo 'please enter your address';}else{echo htmlspecialchars($fetch_profile['address']);} ?></span></p>
         <a href="update_address.php" class="btn" aria-label="Update your delivery address">update address</a>
      </div>

   </section>

</main>

<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>