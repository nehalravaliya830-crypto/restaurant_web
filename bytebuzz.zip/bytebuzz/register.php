<?php
include 'components/connect.php';
session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
}

if(isset($_POST['submit'])){

   $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
   $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
   $number = filter_var($_POST['number'], FILTER_SANITIZE_STRING);
   $address = filter_var($_POST['address'], FILTER_SANITIZE_STRING);
   $pass = filter_var($_POST['pass'], FILTER_SANITIZE_STRING);
   $cpass = filter_var($_POST['cpass'], FILTER_SANITIZE_STRING);

   // hash password securely
   $hashed_pass = sha1($pass);
   $hashed_cpass = sha1($cpass);

   // check if email or number exists
   $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ? OR number = ?");
   $select_user->execute([$email, $number]);

   if($select_user->rowCount() > 0){
      $message[] = 'Email or number already exists!';
   }else{
      if($hashed_pass != $hashed_cpass){
         $message[] = 'Confirm password not matched!';
      }else{
         // insert new user
         $insert_user = $conn->prepare("INSERT INTO `users` (name, email, number, password, address) VALUES (?, ?, ?, ?, ?)");
         $insert_user->execute([$name, $email, $number, $hashed_pass, $address]);

         // auto login after registration
         $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ? AND password = ?");
         $select_user->execute([$email, $hashed_pass]);
         $row = $select_user->fetch(PDO::FETCH_ASSOC);

         if($select_user->rowCount() > 0){
            $_SESSION['user_id'] = $row['id'];
            header('location:home.php');
            exit;
         }
      }
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register Account - ByteBuzz</title>

   <!-- font awesome cdn link -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts -->
<?php include 'components/user_header.php'; ?>
<!-- header section ends -->

<main id="main-content">

   <h1 class="sr-only">Create New Account</h1>

   <section class="form-container">

      <form action="" method="post" aria-labelledby="register-heading">
         <h2 id="register-heading" style="font-size:2.5rem; text-transform:uppercase; margin-bottom:1rem; color:var(--black);">Register Now</h2>
         
         <label for="reg-name" class="sr-only">Full Name</label>
         <input type="text" id="reg-name" name="name" required placeholder="Enter your name" class="box" maxlength="50" autocomplete="name" aria-required="true">
         
         <label for="reg-email" class="sr-only">Email Address</label>
         <input type="email" id="reg-email" name="email" required placeholder="Enter your email" class="box" maxlength="50" autocomplete="email" aria-required="true" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <label for="reg-number" class="sr-only">10-Digit Mobile Number</label>
         <input type="tel" id="reg-number" name="number" required placeholder="Enter your 10-digit number" class="box" maxlength="10" pattern="[0-9]{10}" autocomplete="tel" aria-required="true" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
         
         <label for="reg-address" class="sr-only">Street Address</label>
         <input type="text" id="reg-address" name="address" required placeholder="Enter your address" class="box" maxlength="500" autocomplete="street-address" aria-required="true">
         
         <label for="reg-pass" class="sr-only">Password</label>
         <input type="password" id="reg-pass" name="pass" required placeholder="Enter your password" class="box" maxlength="50" autocomplete="new-password" aria-required="true" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <label for="reg-cpass" class="sr-only">Confirm Password</label>
         <input type="password" id="reg-cpass" name="cpass" required placeholder="Confirm your password" class="box" maxlength="50" autocomplete="new-password" aria-required="true" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <input type="submit" value="Register Now" name="submit" class="btn">
         <p>Already have an account? <a href="login.php">Login now</a></p>
      </form>

      <!-- show error/success messages -->
      <?php
      if(isset($message)){
         foreach($message as $msg){
            echo '<p class="empty" role="alert" style="margin-top:1.5rem;">'.htmlspecialchars($msg).'</p>';
         }
      }
      ?>

   </section>

</main>

<?php include 'components/footer.php'; ?>

<!-- custom js file link -->
<script src="js/script.js"></script>

</body>
</html>
