<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
   exit;
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_message = $conn->prepare("DELETE FROM `messages` WHERE id = ?");
   $delete_message->execute([$delete_id]);
   header('location:messages.php');
   exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Messages - ByteBuzz Admin</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php' ?>

<!-- messages section starts  -->

<main id="main-content">

   <section class="messages" aria-labelledby="messages-heading">

      <h1 class="heading" id="messages-heading">messages</h1>

      <div class="box-container">

      <?php
         $select_messages = $conn->prepare("SELECT * FROM `messages`");
         $select_messages->execute();
         if($select_messages->rowCount() > 0){
            while($fetch_messages = $select_messages->fetch(PDO::FETCH_ASSOC)){
               $sender_name = htmlspecialchars($fetch_messages['name']);
               $msg_id = htmlspecialchars($fetch_messages['id']);
      ?>
      <div class="box">
         <p> name : <span><?= $sender_name; ?></span> </p>
         <p> number : <span><?= htmlspecialchars($fetch_messages['number']); ?></span> </p>
         <p> email : <span><?= htmlspecialchars($fetch_messages['email']); ?></span> </p>
         <p> message : <span><?= htmlspecialchars($fetch_messages['message']); ?></span> </p>
         <a href="messages.php?delete=<?= $msg_id; ?>" class="delete-btn" onclick="return confirm('delete this message?');" aria-label="Delete message from <?= $sender_name; ?>">delete</a>
      </div>
      <?php
            }
         }else{
            echo '<p class="empty" role="status">you have no messages</p>';
         }
      ?>

      </div>

   </section>

</main>

<!-- messages section ends -->

<!-- custom js file link  -->
<script src="../js/admin_script.js"></script>

</body>
</html>