<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
   exit;
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_admin = $conn->prepare("DELETE FROM `admin` WHERE id = ?");
   $delete_admin->execute([$delete_id]);
   header('location:admin_accounts.php');
   exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Admin Accounts - ByteBuzz Admin</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php' ?>

<!-- admins accounts section starts  -->

<main id="main-content">

   <section class="accounts" aria-labelledby="admin-accounts-heading">

      <h1 class="heading" id="admin-accounts-heading">admins account</h1>

      <div class="box-container">

      <div class="box">
         <p>register new admin</p>
         <a href="register_admin.php" class="option-btn" aria-label="Register a new administrator">register</a>
      </div>

      <?php
         $select_account = $conn->prepare("SELECT * FROM `admin`");
         $select_account->execute();
         if($select_account->rowCount() > 0){
            while($fetch_accounts = $select_account->fetch(PDO::FETCH_ASSOC)){  
               $account_name = htmlspecialchars($fetch_accounts['name']);
               $account_id = htmlspecialchars($fetch_accounts['id']);
      ?>
      <div class="box">
         <p> admin id : <span><?= $account_id; ?></span> </p>
         <p> username : <span><?= $account_name; ?></span> </p>
         <div class="flex-btn">
            <a href="admin_accounts.php?delete=<?= $account_id; ?>" class="delete-btn" onclick="return confirm('delete this account?');" aria-label="Delete admin account <?= $account_name; ?>">delete</a>
            <?php
               if($fetch_accounts['id'] == $admin_id){
                  echo '<a href="update_profile.php" class="option-btn" aria-label="Update your admin profile">update</a>';
               }
            ?>
         </div>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty" role="status">no accounts available</p>';
      }
      ?>

      </div>

   </section>

</main>

<!-- admins accounts section ends -->

<!-- custom js file link  -->
<script src="../js/admin_script.js"></script>

</body>
</html>