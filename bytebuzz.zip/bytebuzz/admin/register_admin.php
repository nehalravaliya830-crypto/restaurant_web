<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
   exit;
};

if(isset($_POST['submit'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);
   $cpass = sha1($_POST['cpass']);
   $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

   $select_admin = $conn->prepare("SELECT * FROM `admin` WHERE name = ?");
   $select_admin->execute([$name]);
   
   if($select_admin->rowCount() > 0){
      $message[] = 'username already exists!';
   }else{
      if($pass != $cpass){
         $message[] = 'confirm password not matched!';
      }else{
         $insert_admin = $conn->prepare("INSERT INTO `admin`(name, password) VALUES(?,?)");
         $insert_admin->execute([$name, $cpass]);
         $message[] = 'new admin registered!';
      }
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register New Admin - ByteBuzz Admin</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php' ?>

<!-- register admin section starts  -->

<main id="main-content">

   <h1 class="sr-only">Register New Administrator</h1>

   <section class="form-container">

      <form action="" method="POST" aria-labelledby="reg-admin-heading">
         <h2 id="reg-admin-heading" style="font-size:2.5rem; text-transform:capitalize; margin-bottom:1rem; color:var(--black);">register new</h2>
         
         <label for="reg-admin-name" class="sr-only">Admin Username</label>
         <input type="text" id="reg-admin-name" name="name" maxlength="20" required placeholder="enter your username" class="box" autocomplete="username" aria-required="true" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <label for="reg-admin-pass" class="sr-only">Admin Password</label>
         <input type="password" id="reg-admin-pass" name="pass" maxlength="20" required placeholder="enter your password" class="box" autocomplete="new-password" aria-required="true" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <label for="reg-admin-cpass" class="sr-only">Confirm Admin Password</label>
         <input type="password" id="reg-admin-cpass" name="cpass" maxlength="20" required placeholder="confirm your password" class="box" autocomplete="new-password" aria-required="true" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <input type="submit" value="register now" name="submit" class="btn">
      </form>

   </section>

</main>

<!-- register admin section ends -->

<!-- custom js file link  -->
<script src="../js/admin_script.js"></script>

</body>
</html>