<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
   exit;
}

// Update order status
if(isset($_POST['update_status'])){
   $order_id = $_POST['order_id'];
   $status = $_POST['order_status'];

   if(empty($status)){
      $message[] = 'Please select a valid order status!';
   } else {
      $update_status = $conn->prepare("UPDATE `orders` SET order_status = ? WHERE id = ?");
      $update_status->execute([$status, $order_id]);
      $message[] = 'Order status updated!';
   }
}

// Delete order
if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_order = $conn->prepare("DELETE FROM `orders` WHERE id = ?");
   $delete_order->execute([$delete_id]);
   header('location:placed_orders.php');
   exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <title>Placed Orders - ByteBuzz Admin</title>

   <!-- font awesome cdn link  -->
   <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
   />

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css" />
</head>
<body>

<?php include '../components/admin_header.php' ?>

<main id="main-content">

   <section class="placed-orders" aria-labelledby="placed-orders-heading">

      <h1 class="heading" id="placed-orders-heading">Placed Orders</h1>

      <div class="box-container">

      <?php
         $select_orders = $conn->prepare("SELECT * FROM `orders` ORDER BY placed_on DESC");
         $select_orders->execute();
         if($select_orders->rowCount() > 0){
            while($fetch_orders = $select_orders->fetch(PDO::FETCH_ASSOC)){
               $ord_id = htmlspecialchars($fetch_orders['id']);
               $status_text = htmlspecialchars($fetch_orders['order_status']);
               $status_color = match($status_text){
                  'Accepted' => '#b76e00',
                  'Delivered' => '#2e7d32',
                  'Cancelled' => '#c0392b',
                  default => '#595959'
               };
      ?>
      <div class="box">
         <p><strong>User ID:</strong> <span><?= htmlspecialchars($fetch_orders['user_id']); ?></span></p>
         <p><strong>Placed on:</strong> <span><?= htmlspecialchars($fetch_orders['placed_on']); ?></span></p>
         <p><strong>Name:</strong> <span><?= htmlspecialchars($fetch_orders['name']); ?></span></p>
         <p><strong>Email:</strong> <span><?= htmlspecialchars($fetch_orders['email']); ?></span></p>
         <p><strong>Number:</strong> <span><?= htmlspecialchars($fetch_orders['number']); ?></span></p>
         <p><strong>Address:</strong> <span><?= htmlspecialchars($fetch_orders['address']); ?></span></p>
         <p><strong>Total products:</strong> <span><?= htmlspecialchars($fetch_orders['total_products']); ?></span></p>
         <p><strong>Total price:</strong> <span>₹<?= htmlspecialchars($fetch_orders['total_price']); ?>/-</span></p>
         <p><strong>Payment method:</strong> <span><?= htmlspecialchars($fetch_orders['method']); ?></span></p>
         
         <p><strong>Order Status:</strong> 
            <strong style="color:<?= $status_color; ?>;">
               <?= $status_text; ?>
            </strong>
         </p>

         <form action="" method="POST">
            <input type="hidden" name="order_id" value="<?= $ord_id; ?>" />
            <label for="status-<?= $ord_id; ?>" class="sr-only">Change Status for Order #<?= $ord_id; ?></label>
            <select id="status-<?= $ord_id; ?>" name="order_status" class="drop-down" required aria-required="true">
               <option value="" disabled selected>-- Change Status --</option>
               <option value="Pending">Pending</option>
               <option value="Accepted">Accepted</option>
               <option value="Delivered">Delivered</option>
               <option value="Cancelled">Cancelled</option>
            </select>
            <div class="flex-btn">
               <input type="submit" value="Update" class="btn" name="update_status" aria-label="Update status for Order #<?= $ord_id; ?>" />
               <a
                  href="placed_orders.php?delete=<?= $ord_id; ?>"
                  class="delete-btn"
                  onclick="return confirm('Are you sure you want to delete this order permanently?');"
                  aria-label="Delete Order #<?= $ord_id; ?>"
                  >Delete</a
               >
            </div>
         </form>
      </div>
      <?php
            }
         } else {
            echo '<p class="empty" role="status">No orders placed yet!</p>';
         }
      ?>

      </div>

   </section>

</main>

<script src="../js/admin_script.js"></script>

</body>
</html>
