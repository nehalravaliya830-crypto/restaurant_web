<?php

include '../components/connect.php';

session_start();

if(isset($_POST['submit'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);

   $select_admin = $conn->prepare("SELECT * FROM `admin` WHERE name = ? AND password = ?");
   $select_admin->execute([$name, $pass]);
   
   if($select_admin->rowCount() > 0){
      $fetch_admin_id = $select_admin->fetch(PDO::FETCH_ASSOC);
      $_SESSION['admin_id'] = $fetch_admin_id['id'];
      header('location:dashboard.php');
      exit;
   }else{
      $message[] = 'incorrect username or password!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Admin Login - ByteBuzz Admin Panel</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<a href="#main-content" class="skip-link">Skip to main content</a>

<?php
if(isset($message)){
   foreach($message as $msg){
      echo '
      <div class="message" role="alert">
         <span>'.htmlspecialchars($msg).'</span>
         <button type="button" class="fas fa-times" aria-label="Dismiss message" onclick="this.parentElement.remove();" style="background:transparent;border:none;"></button>
      </div>
      ';
   }
}
?>

<!-- admin login form section starts  -->

<main id="main-content">

   <section class="form-container">

      <form action="" method="POST" aria-labelledby="admin-login-heading">
         <h1 id="admin-login-heading" style="font-size:2.5rem; text-transform:capitalize; margin-bottom:1rem; color:var(--black);">admin login</h1>
        
         <label for="admin-name" class="sr-only">Admin Username</label>
         <input type="text" id="admin-name" name="name" maxlength="20" required placeholder="Enter your username" class="box" autocomplete="username" aria-required="true" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <label for="admin-pass" class="sr-only">Admin Password</label>
         <input type="password" id="admin-pass" name="pass" maxlength="20" required placeholder="Enter your password" class="box" autocomplete="current-password" aria-required="true" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <input type="submit" value="login now" name="submit" class="btn">
      </form>

   </section>

</main>

<!-- admin login form section ends -->

<script src="../js/admin_script.js"></script>

</body>
</html>