<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
   exit;
};

if(isset($_POST['add_product'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $price = $_POST['price'];
   $price = filter_var($price, FILTER_SANITIZE_STRING);
   $category = $_POST['category'];
   $category = filter_var($category, FILTER_SANITIZE_STRING);

   $image = $_FILES['image']['name'];
   $image = filter_var($image, FILTER_SANITIZE_STRING);
   $image_size = $_FILES['image']['size'];
   $image_tmp_name = $_FILES['image']['tmp_name'];
   $image_folder = '../uploaded_img/'.$image;

   $select_products = $conn->prepare("SELECT * FROM `products` WHERE name = ?");
   $select_products->execute([$name]);

   if($select_products->rowCount() > 0){
      $message[] = 'product name already exists!';
   }else{
      if($image_size > 2000000){
         $message[] = 'image size is too large';
      }else{
         move_uploaded_file($image_tmp_name, $image_folder);

         $insert_product = $conn->prepare("INSERT INTO `products`(name, category, price, image) VALUES(?,?,?,?)");
         $insert_product->execute([$name, $category, $price, $image]);

         $message[] = 'new product added!';
      }

   }

}

if(isset($_GET['delete'])){

   $delete_id = $_GET['delete'];
   $delete_product_image = $conn->prepare("SELECT * FROM `products` WHERE id = ?");
   $delete_product_image->execute([$delete_id]);
   $fetch_delete_image = $delete_product_image->fetch(PDO::FETCH_ASSOC);
   if($fetch_delete_image && file_exists('../uploaded_img/'.$fetch_delete_image['image'])){
      unlink('../uploaded_img/'.$fetch_delete_image['image']);
   }
   $delete_product = $conn->prepare("DELETE FROM `products` WHERE id = ?");
   $delete_product->execute([$delete_id]);
   $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE pid = ?");
   $delete_cart->execute([$delete_id]);
   header('location:products.php');
   exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Product Management - ByteBuzz Admin</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php' ?>

<main id="main-content">

   <h1 class="heading">manage products</h1>

   <!-- add products section starts  -->

   <section class="add-products" aria-labelledby="add-product-heading">

      <form action="" method="POST" enctype="multipart/form-data">
         <h2 id="add-product-heading" style="font-size:2.5rem; text-transform:capitalize; margin-bottom:1rem; color:var(--black);">add product</h2>
         
         <label for="prod-name" class="sr-only">Product Name</label>
         <input type="text" id="prod-name" required placeholder="enter product name" name="name" maxlength="100" class="box" aria-required="true">
         
         <label for="prod-price" class="sr-only">Product Price (INR)</label>
         <input type="number" id="prod-price" min="0" max="9999999999" required placeholder="enter product price" name="price" onkeypress="if(this.value.length == 10) return false;" class="box" aria-required="true">
         
         <label for="prod-cat" class="sr-only">Select Category</label>
         <select id="prod-cat" name="category" class="box" required aria-required="true">
            <option value="" disabled selected>select category --</option>
            <option value="MAIN DISH">MAIN DISH</option>
            <option value="FAST FOOD">FAST FOOD</option>
            <option value="DRINKS">DRINKS</option>
            <option value="DESSERTS">DESSERTS</option>
         </select>
         
         <label for="prod-image" class="sr-only">Product Image</label>
         <input type="file" id="prod-image" name="image" class="box" accept="image/jpg, image/jpeg, image/png, image/webp" required aria-required="true">
         
         <input type="submit" value="add product" name="add_product" class="btn">
      </form>

   </section>

   <!-- add products section ends -->

   <!-- show products section starts  -->

   <section class="show-products" style="padding-top: 0;" aria-label="Existing Products">

      <div class="box-container">

      <?php
         $show_products = $conn->prepare("SELECT * FROM `products`");
         $show_products->execute();
         if($show_products->rowCount() > 0){
            while($fetch_products = $show_products->fetch(PDO::FETCH_ASSOC)){  
      ?>
      <div class="box">
         <img src="../uploaded_img/<?= htmlspecialchars($fetch_products['image']); ?>" alt="<?= htmlspecialchars($fetch_products['name']); ?>">
         <div class="flex">
            <div class="price"><span>₹</span><?= $fetch_products['price']; ?><span>/-</span></div>
            <div class="category"><?= htmlspecialchars($fetch_products['category']); ?></div>
         </div>
         <div class="name"><?= htmlspecialchars($fetch_products['name']); ?></div>
         <div class="flex-btn">
            <a href="update_product.php?update=<?= $fetch_products['id']; ?>" class="option-btn" aria-label="Update <?= htmlspecialchars($fetch_products['name']); ?>">update</a>
            <a href="products.php?delete=<?= $fetch_products['id']; ?>" class="delete-btn" onclick="return confirm('delete this product?');" aria-label="Delete <?= htmlspecialchars($fetch_products['name']); ?>">delete</a>
         </div>
      </div>
      <?php
            }
         }else{
            echo '<p class="empty" role="status">no products added yet!</p>';
         }
      ?>

      </div>

   </section>

   <!-- show products section ends -->

</main>

<!-- custom js file link  -->
<script src="../js/admin_script.js"></script>

</body>
</html>