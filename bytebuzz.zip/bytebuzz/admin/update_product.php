<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
   exit;
};

if(isset($_POST['update'])){

   $pid = $_POST['pid'];
   $pid = filter_var($pid, FILTER_SANITIZE_STRING);
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $price = $_POST['price'];
   $price = filter_var($price, FILTER_SANITIZE_STRING);
   $category = $_POST['category'];
   $category = filter_var($category, FILTER_SANITIZE_STRING);

   $update_product = $conn->prepare("UPDATE `products` SET name = ?, category = ?, price = ? WHERE id = ?");
   $update_product->execute([$name, $category, $price, $pid]);

   $message[] = 'product updated!';

   $old_image = $_POST['old_image'];
   $image = $_FILES['image']['name'];
   $image = filter_var($image, FILTER_SANITIZE_STRING);
   $image_size = $_FILES['image']['size'];
   $image_tmp_name = $_FILES['image']['tmp_name'];
   $image_folder = '../uploaded_img/'.$image;

   if(!empty($image)){
      if($image_size > 2000000){
         $message[] = 'images size is too large!';
      }else{
         $update_image = $conn->prepare("UPDATE `products` SET image = ? WHERE id = ?");
         $update_image->execute([$image, $pid]);
         move_uploaded_file($image_tmp_name, $image_folder);
         if(file_exists('../uploaded_img/'.$old_image)){
            unlink('../uploaded_img/'.$old_image);
         }
         $message[] = 'image updated!';
      }
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Update Product - ByteBuzz Admin</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php' ?>

<!-- update product section starts  -->

<main id="main-content">

   <section class="update-product" aria-labelledby="update-prod-title">

      <h1 class="heading" id="update-prod-title">update product</h1>

      <?php
         $update_id = $_GET['update'] ?? '';
         $show_products = $conn->prepare("SELECT * FROM `products` WHERE id = ?");
         $show_products->execute([$update_id]);
         if($show_products->rowCount() > 0){
            while($fetch_products = $show_products->fetch(PDO::FETCH_ASSOC)){  
      ?>
      <form action="" method="POST" enctype="multipart/form-data">
         <input type="hidden" name="pid" value="<?= $fetch_products['id']; ?>">
         <input type="hidden" name="old_image" value="<?= htmlspecialchars($fetch_products['image']); ?>">
         <img src="../uploaded_img/<?= htmlspecialchars($fetch_products['image']); ?>" alt="<?= htmlspecialchars($fetch_products['name']); ?>">
         
         <label for="up-prod-name">update name</label>
         <input type="text" id="up-prod-name" required placeholder="enter product name" name="name" maxlength="100" class="box" value="<?= htmlspecialchars($fetch_products['name']); ?>" aria-required="true">
         
         <label for="up-prod-price">update price</label>
         <input type="number" id="up-prod-price" min="0" max="9999999999" required placeholder="enter product price" name="price" onkeypress="if(this.value.length == 10) return false;" class="box" value="<?= $fetch_products['price']; ?>" aria-required="true">
         
         <label for="up-prod-cat">update category</label>
         <select id="up-prod-cat" name="category" class="box" required aria-required="true">
            <option selected value="<?= htmlspecialchars($fetch_products['category']); ?>"><?= htmlspecialchars($fetch_products['category']); ?></option>
            <option value="MAIN DISH">MAIN DISH</option>
            <option value="FAST FOOD">FAST FOOD</option>
            <option value="DRINKS">DRINKS</option>
            <option value="DESSERTS">DESSERTS</option>
         </select>
         
         <label for="up-prod-img">update image</label>
         <input type="file" id="up-prod-img" name="image" class="box" accept="image/jpg, image/jpeg, image/png, image/webp">
         
         <div class="flex-btn">
            <input type="submit" value="update" class="btn" name="update">
            <a href="products.php" class="option-btn" aria-label="Cancel and return to product list">go back</a>
         </div>
      </form>
      <?php
            }
         }else{
            echo '<p class="empty" role="status">no products found!</p>';
         }
      ?>

   </section>

</main>

<!-- update product section ends -->

<!-- custom js file link  -->
<script src="../js/admin_script.js"></script>

</body>
</html>