<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
   exit;
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_users = $conn->prepare("DELETE FROM `users` WHERE id = ?");
   $delete_users->execute([$delete_id]);
   $delete_order = $conn->prepare("DELETE FROM `orders` WHERE user_id = ?");
   $delete_order->execute([$delete_id]);
   $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
   $delete_cart->execute([$delete_id]);
   header('location:users_accounts.php');
   exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>User Accounts - ByteBuzz Admin</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php' ?>

<!-- user accounts section starts  -->

<main id="main-content">

   <section class="accounts" aria-labelledby="user-accounts-heading">

      <h1 class="heading" id="user-accounts-heading">users account</h1>

      <div class="box-container">

      <?php
         $select_account = $conn->prepare("SELECT * FROM `users`");
         $select_account->execute();
         if($select_account->rowCount() > 0){
            while($fetch_accounts = $select_account->fetch(PDO::FETCH_ASSOC)){  
               $account_name = htmlspecialchars($fetch_accounts['name']);
               $account_id = htmlspecialchars($fetch_accounts['id']);
      ?>
      <div class="box">
         <p> user id : <span><?= $account_id; ?></span> </p>
         <p> username : <span><?= $account_name; ?></span> </p>
         <a href="users_accounts.php?delete=<?= $account_id; ?>" class="delete-btn" onclick="return confirm('delete this account?');" aria-label="Delete user account <?= $account_name; ?>">delete</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty" role="status">no accounts available</p>';
      }
      ?>

      </div>

   </section>

</main>

<!-- user accounts section ends -->

<!-- custom js file link  -->
<script src="../js/admin_script.js"></script>

</body>
</html>