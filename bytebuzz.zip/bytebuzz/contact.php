<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['send'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING);
   $msg = $_POST['msg'];
   $msg = filter_var($msg, FILTER_SANITIZE_STRING);

   $select_message = $conn->prepare("SELECT * FROM `messages` WHERE name = ? AND email = ? AND number = ? AND message = ?");
   $select_message->execute([$name, $email, $number, $msg]);

   if($select_message->rowCount() > 0){
      $message[] = 'already sent message!';
   }else{

      $insert_message = $conn->prepare("INSERT INTO `messages`(user_id, name, email, number, message) VALUES(?,?,?,?,?)");
      $insert_message->execute([$user_id, $name, $email, $number, $msg]);

      $message[] = 'sent message successfully!';

   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Contact Us - ByteBuzz</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->
<?php include 'components/user_header.php'; ?>
<!-- header section ends -->

<main id="main-content">

   <h1 class="sr-only">Contact ByteBuzz</h1>

   <div class="heading" aria-label="Breadcrumb">
      <h2>contact us</h2>
      <p><a href="home.php">HOME</a> <span aria-current="page"> / CONTACT</span></p>
   </div>

   <!-- contact section starts  -->

   <section class="contact" aria-labelledby="contact-heading">

      <div class="row">

         <div class="image">
            <img src="images/contact-img.svg" alt="Friendly ByteBuzz customer support team ready to assist with your inquiries">
         </div>

         <form action="" method="post" aria-labelledby="contact-form-heading">
            <h3 id="contact-form-heading">tell us something!</h3>
            
            <label for="contact-name" class="sr-only">Your Full Name</label>
            <input type="text" id="contact-name" name="name" maxlength="50" class="box" placeholder="Enter Your Name" required autocomplete="name" aria-required="true">
            
            <label for="contact-number" class="sr-only">Your 10 Digit Phone Number</label>
            <input type="tel" id="contact-number" name="number" pattern="[0-9]{10}" maxlength="10" class="box" placeholder="Enter Your Number" required autocomplete="tel" aria-required="true">
            
            <label for="contact-email" class="sr-only">Your Email Address</label>
            <input type="email" id="contact-email" name="email" maxlength="50" class="box" placeholder="Enter Your Email" required autocomplete="email" aria-required="true">
            
            <label for="contact-msg" class="sr-only">Your Message</label>
            <textarea id="contact-msg" name="msg" class="box" required placeholder="Enter Your Message" maxlength="500" cols="30" rows="10" aria-required="true"></textarea>
            
            <input type="submit" value="send message" name="send" class="btn">
         </form>

      </div>

   </section>

   <!-- contact section ends -->

</main>

<!-- footer section starts  -->
<?php include 'components/footer.php'; ?>
<!-- footer section ends -->

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>