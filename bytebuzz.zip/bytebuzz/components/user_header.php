<a href="#main-content" class="skip-link">Skip to main content</a>

<?php
if(isset($message)){
   foreach($message as $msg){
      echo '
      <div class="message" role="status" aria-live="polite">
         <span>'.htmlspecialchars($msg).'</span>
         <button type="button" class="fas fa-times" aria-label="Dismiss notification" onclick="this.parentElement.remove();" style="background:transparent;border:none;"></button>
      </div>
      ';
   }
}
?>

<header class="header">

   <section class="flex">

      <a href="home.php" class="logo" aria-label="ByteBuzz Home">ByteBuzz<span aria-hidden="true">🍽</span></a>

      <nav class="navbar" id="main-nav" aria-label="Primary Navigation">
         <a href="home.php">HOME</a>
         <a href="about.php">ABOUT</a>
         <a href="menu.php">MENU</a>
         <a href="orders.php">ORDERS</a>
         <a href="contact.php">CONTACT</a>
      </nav>

      <div class="icons">
         <?php
            $count_cart_items = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
            $count_cart_items->execute([$user_id]);
            $total_cart_items = $count_cart_items->rowCount();
         ?>
         <a href="search.php" aria-label="Search dishes and menu"><i class="fas fa-search" aria-hidden="true"></i><span class="sr-only">Search</span></a>
         <a href="cart.php" aria-label="Shopping Cart, <?= $total_cart_items; ?> items"><i class="fas fa-shopping-cart" aria-hidden="true"></i><span>(<?= $total_cart_items; ?>)</span></a>
         <button type="button" id="user-btn" class="fas fa-user" aria-label="User profile and account options" aria-expanded="false" aria-controls="user-profile-dropdown"></button>
         <button type="button" id="menu-btn" class="fas fa-bars" aria-label="Toggle navigation menu" aria-expanded="false" aria-controls="main-nav"></button>
      </div>

      <div class="profile" id="user-profile-dropdown" role="region" aria-label="User Account Information">
         <?php
            $select_profile = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
            $select_profile->execute([$user_id]);
            if($select_profile->rowCount() > 0){
               $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
         ?>
         <p class="name"><?= htmlspecialchars($fetch_profile['name']); ?></p>
         <div class="flex">
            <a href="profile.php" class="btn">profile</a>
            <a href="components/user_logout.php" onclick="return confirm('logout from this website?');" class="delete-btn">logout</a>
         </div>
         <p class="account">
            <a href="login.php">login</a> or
            <a href="register.php">register</a>
         </p> 
         <?php
            }else{
         ?>
            <p class="name">please login first!</p>
            <a href="login.php" class="btn">login</a>
         <?php
          }
         ?>
      </div>

   </section>

</header>
