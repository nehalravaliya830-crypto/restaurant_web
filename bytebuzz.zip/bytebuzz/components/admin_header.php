<a href="#main-content" class="skip-link">Skip to main content</a>

<?php
if(isset($message)){
   foreach($message as $msg){
      echo '
      <div class="message" role="status" aria-live="polite">
         <span>'.htmlspecialchars($msg).'</span>
         <button type="button" class="fas fa-times" aria-label="Dismiss notification" onclick="this.parentElement.remove();" style="background:transparent;border:none;"></button>
      </div>
      ';
   }
}
?>

<header class="header">

   <section class="flex">

      <a href="dashboard.php" class="logo" aria-label="Admin Panel Dashboard">Admin<span>Panel</span></a>

      <nav class="navbar" id="admin-nav" aria-label="Admin Navigation">
         <a href="dashboard.php">HOME</a>
         <a href="products.php">PRODUCTS</a>
         <a href="placed_orders.php">ORDERS</a>
         <a href="admin_accounts.php">ADMINS</a>
         <a href="users_accounts.php">USERS</a>
         <a href="messages.php">MESSAGES</a>
      </nav>

      <div class="icons">
         <button type="button" id="menu-btn" class="fas fa-bars" aria-label="Toggle navigation menu" aria-expanded="false" aria-controls="admin-nav"></button>
         <button type="button" id="user-btn" class="fas fa-user" aria-label="Admin profile options" aria-expanded="false" aria-controls="admin-profile-dropdown"></button>
      </div>

      <div class="profile" id="admin-profile-dropdown" role="region" aria-label="Admin Profile Details">
         <?php
            $select_profile = $conn->prepare("SELECT * FROM `admin` WHERE id = ?");
            $select_profile->execute([$admin_id]);
            $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
         ?>
         <p><?= htmlspecialchars($fetch_profile['name'] ?? 'Admin'); ?></p>
         <a href="update_profile.php" class="btn">update profile</a>
         <div class="flex-btn">
            <a href="admin_login.php" class="option-btn">login</a>
            <a href="register_admin.php" class="option-btn">register</a>
         </div>
         <a href="../components/admin_logout.php" onclick="return confirm('logout from this website?');" class="delete-btn">logout</a>
      </div>

   </section>

</header>