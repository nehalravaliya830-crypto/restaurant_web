<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About Us - ByteBuzz Authentic Vegetarian</title>

   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->
<?php include 'components/user_header.php'; ?>
<!-- header section ends -->

<main id="main-content">

   <h1 class="sr-only">About ByteBuzz Vegetarian Restaurant</h1>

   <div class="heading" aria-label="Breadcrumb">
      <h2>about us</h2>
      <p><a href="home.php">HOME</a> <span aria-current="page">/ABOUT</span></p>
   </div>

   <!-- about section starts  -->

   <section class="about" aria-labelledby="why-choose-us">

      <div class="row">

         <div class="image">
            <img src="images/about-img.svg" alt="Chefs preparing fresh, authentic vegetarian cuisine at ByteBuzz">
         </div>

         <div class="content">
            <h2 id="why-choose-us" style="font-size:3rem; margin-bottom:1rem; text-transform:capitalize;">why choose us?</h2>
            <p>Welcome to ByteBuzz, your destination for authentic Indian vegetarian food.
   We serve fresh, hygienic, and wholesome meals made with love.
   Our menu combines traditional flavors with a modern touch.
   From curries to snacks, every dish is crafted to delight.
   At ByteBuzz, we bring you the pure taste of India.<br>
            <a href="menu.php" class="btn">Our Menu</a>
         </div>

      </div>

   </section>

   <!-- about section ends -->

   <!-- steps section starts  -->

   <section class="steps" aria-labelledby="steps-title">

      <h2 class="title" id="steps-title">SIMPLE STEPS</h2>

      <div class="box-container">

         <div class="box">
            <img src="images/step-1.png" alt="" aria-hidden="true">
            <h3>choose order</h3>
            <p>Choose your favorite dishes from our menu and add them to your cart.
   Place your order easily with just a few clicks.</p>
         </div>

         <div class="box">
            <img src="images/step-2.png" alt="" aria-hidden="true">
            <h3>fast delivery</h3>
            <p>FAST DELIVERY of your favorite meals at your doorstep.
   We ensure every order is fresh, hot, and on time.</p>
         </div>

         <div class="box">
            <img src="images/step-3.png" alt="" aria-hidden="true">
            <h3>enjoy food</h3>
            <p>ENJOY FOOD that is fresh, healthy, and full of flavor.
   Every bite brings you the true taste of happiness.</p>
         </div>

      </div>

   </section>

   <!-- steps section ends -->

   <!-- reviews section starts  -->

   <section class="reviews" aria-labelledby="reviews-title">

      <h2 class="title" id="reviews-title">customer's reviews</h2>

      <div class="swiper reviews-slider" aria-label="Customer Testimonials">

         <div class="swiper-wrapper">

            <div class="swiper-slide slide">
               <img src="images/pic-1.png" alt="Alex Sampson, Customer">
               <p>Food was amazing, full of authentic Indian taste.
   Every dish felt fresh and well prepared.
   I’ll definitely come back again!.</p>
               <div class="stars" role="img" aria-label="Rating: 4.5 out of 5 stars">
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star-half-alt" aria-hidden="true"></i>
               </div>
               <h3>Alex Sampson</h3>
            </div>

            <div class="swiper-slide slide">
               <img src="images/pic-2.png" alt="Tanvi Gadara, Customer">
               <p>Fast delivery and hot food on arrival.
   Loved the flavors, very homely feeling.
   Perfect for quick and tasty meals.</p>
               <div class="stars" role="img" aria-label="Rating: 4.5 out of 5 stars">
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star-half-alt" aria-hidden="true"></i>
               </div>
               <h3>Tanvi Gadara</h3>
            </div>

            <div class="swiper-slide slide">
               <img src="images/pic-3.png" alt="Steve Harrington, Customer">
               <p>Great hospitality and excellent service.
   Every bite was filled with freshness.
   Loved the cozy restaurant vibe.</p>
               <div class="stars" role="img" aria-label="Rating: 4.5 out of 5 stars">
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star-half-alt" aria-hidden="true"></i>
               </div>
               <h3>Steve Harrington</h3>
            </div>

            <div class="swiper-slide slide">
               <img src="images/pic-4.png" alt="Princy Jetani, Customer">
               <p>Budget-friendly and healthy choices here.
   Hygiene is top-notch and food is great.
   My go-to place for family dinners.</p>
               <div class="stars" role="img" aria-label="Rating: 4.5 out of 5 stars">
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star-half-alt" aria-hidden="true"></i>
               </div>
               <h3>Princy Jetani</h3>
            </div>

            <div class="swiper-slide slide">
               <img src="images/pic-5.png" alt="Jay Ravaliya, Customer">
               <p>Tried their thali – a complete treat!
   Perfect balance of spices and flavors.
   Truly satisfying vegetarian meals.</p>
               <div class="stars" role="img" aria-label="Rating: 4.5 out of 5 stars">
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star-half-alt" aria-hidden="true"></i>
               </div>
               <h3>Jay Ravaliya</h3>
            </div>

            <div class="swiper-slide slide">
               <img src="images/pic-6.png" alt="Bae Suzy, Customer">
               <p>Smooth ordering and quick delivery.
   The food tasted fresh and authentic.
   Really impressed with ByteBuzz service.</p>
               <div class="stars" role="img" aria-label="Rating: 4.5 out of 5 stars">
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star-half-alt" aria-hidden="true"></i>
               </div>
               <h3>Bae Suzy</h3>
            </div>

         </div>

         <div class="swiper-pagination"></div>

      </div>

   </section>

   <!-- reviews section ends -->

</main>

<!-- footer section starts  -->
<?php include 'components/footer.php'; ?>
<!-- footer section ends -->

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

<script>

var swiper = new Swiper(".reviews-slider", {
   loop:true,
   grabCursor: true,
   spaceBetween: 20,
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
   },
   breakpoints: {
      0: {
      slidesPerView: 1,
      },
      700: {
      slidesPerView: 2,
      },
      1024: {
      slidesPerView: 3,
      },
   },
});

</script>

</body>
</html>