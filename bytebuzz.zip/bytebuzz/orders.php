<?php
include 'components/connect.php';

session_start();

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
} else {
    header('location:home.php');
    exit;
}

// Cancel order request
if (isset($_POST['cancel_order'])) {
    $order_id = $_POST['order_id'];
    $update_cancel = $conn->prepare("UPDATE orders SET order_status = 'Cancelled' WHERE id = ? AND user_id = ?");
    $update_cancel->execute([$order_id, $user_id]);
    $message[] = 'order cancelled successfully!';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Your Orders - ByteBuzz</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'components/user_header.php'; ?>

<main id="main-content">

   <div class="heading" aria-label="Breadcrumb">
      <h2>Orders</h2>
      <p><a href="home.php">Home</a> <span aria-current="page"> / Orders</span></p>
   </div>

   <section class="orders" aria-labelledby="orders-title">
      <h1 class="title" id="orders-title">Your Orders</h1>

      <div class="box-container">

      <?php
      $select_orders = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY placed_on DESC");
      $select_orders->execute([$user_id]);

      if ($select_orders->rowCount() > 0) {
          while ($fetch_orders = $select_orders->fetch(PDO::FETCH_ASSOC)) {
              $id = htmlspecialchars($fetch_orders['id'] ?? '');
              $placed_on = htmlspecialchars($fetch_orders['placed_on'] ?? '');
              $name = htmlspecialchars($fetch_orders['name'] ?? '');
              $email = htmlspecialchars($fetch_orders['email'] ?? '');
              $number = htmlspecialchars($fetch_orders['number'] ?? '');
              $address = htmlspecialchars($fetch_orders['address'] ?? '');
              $method = htmlspecialchars($fetch_orders['method'] ?? '');
              $total_products = htmlspecialchars($fetch_orders['total_products'] ?? '');
              $total_price = htmlspecialchars($fetch_orders['total_price'] ?? '0');
              $order_status = $fetch_orders['order_status'] ?? 'Pending';
              $payment_status = $fetch_orders['payment_status'] ?? 'pending';

              $method_lower = strtolower($method);
              $pay_status = strtolower($payment_status);
              $ord_status = strtolower($order_status);

              // Accessible payment status determination
              if ($ord_status === 'cancelled') {
                  $payment_display = 'Cancelled';
                  $payment_color = '#595959';
              } elseif ($method_lower === 'cash on delivery') {
                  if ($ord_status === 'delivered') {
                      $payment_display = 'Done';
                      $payment_color = '#2e7d32';
                  } else {
                      $payment_display = 'Pending';
                      $payment_color = '#c0392b';
                  }
              } else {
                  if ($pay_status === 'done') {
                      $payment_display = 'Done';
                      $payment_color = '#2e7d32';
                  } else {
                      $payment_display = 'Pending';
                      $payment_color = '#c0392b';
                  }
              }

              // Accessible order status color
              $order_color = match (ucfirst($order_status)) {
                  'Accepted' => '#b76e00',
                  'Delivered' => '#2e7d32',
                  'Cancelled' => '#c0392b',
                  default => '#595959'
              };
      ?>

      <div class="box">
         <p>Placed on : <span><?= $placed_on; ?></span></p>
         <p>Name : <span><?= $name; ?></span></p>
         <p>Email : <span><?= $email; ?></span></p>
         <p>Number : <span><?= $number; ?></span></p>
         <p>Address : <span><?= $address; ?></span></p>
         <p>Payment type : <span><?= $method; ?></span></p>
         <p>Your orders : <span><?= $total_products; ?></span></p>
         <p>Total price : <span>₹<?= $total_price; ?>/-</span></p>

         <p>Payment Status :
            <strong style="color:<?= $payment_color; ?>;">
               <?= ucfirst($payment_display); ?>
            </strong>
         </p>

         <p>Order Status : 
            <strong style="color:<?= $order_color; ?>;">
               <?= htmlspecialchars($order_status); ?>
            </strong>
         </p>

         <?php if (strtolower($order_status) !== 'delivered' && strtolower($order_status) !== 'cancelled') { ?>
         <form method="post" onsubmit="return confirm('Are you sure you want to cancel this order?');">
            <input type="hidden" name="order_id" value="<?= $id; ?>">
            <button type="submit" name="cancel_order" class="delete-btn" aria-label="Cancel order #<?= $id; ?>">Cancel Order</button>
         </form>
         <?php } ?>

      </div>

      <?php
          }
      } else {
          echo '<p class="empty" role="status">No orders placed yet!</p>';
      }
      ?>

      </div>
   </section>

</main>

<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>
