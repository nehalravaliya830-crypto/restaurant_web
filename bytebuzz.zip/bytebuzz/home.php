<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/add_cart.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>ByteBuzz - Authentic Indian Vegetarian Dining | Home</title>

   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php include 'components/user_header.php'; ?>

<main id="main-content">
   <h1 class="sr-only">ByteBuzz Online Food Ordering</h1>

   <section class="hero" aria-label="Featured Food Promotion">

      <div class="swiper hero-slider">

         <div class="swiper-wrapper">

            <div class="swiper-slide slide">
               <div class="content">
                  <span>Order Online</span>
                  <h3>delicious pizza</h3>
                  <a href="menu.php" class="btn">See Menus</a>
               </div>
               <div class="image">
                  <img src="images/home-img-1.png" alt="Freshly baked delicious vegetarian pizza">
               </div>
            </div>

         </div>

      </div>

   </section>

   <section class="category" aria-labelledby="category-heading">

      <h2 class="title" id="category-heading">FOOD CATEGORY</h2>

      <div class="box-container">

         <a href="category.php?category=FAST FOOD" class="box" aria-label="Fast Food Category">
            <img src="images/cat-1.png" alt="" aria-hidden="true">
            <h3>FAST FOOD</h3>
         </a>

         <a href="category.php?category=MAIN DISH" class="box" aria-label="Main Dishes Category">
            <img src="images/cat-2.png" alt="" aria-hidden="true">
            <h3>MAIN DISHES</h3>
         </a>

         <a href="category.php?category=DRINKS" class="box" aria-label="Drinks Category">
            <img src="images/cat-3.png" alt="" aria-hidden="true">
            <h3>DRINKS</h3>
         </a>

         <a href="category.php?category=DESSERTS" class="box" aria-label="Desserts Category">
            <img src="images/cat-4.png" alt="" aria-hidden="true">
            <h3>DESSERTS</h3>
         </a>

      </div>

   </section>

   <section class="products" aria-labelledby="dishes-heading">

      <h2 class="title" id="dishes-heading">latest dishes</h2>

      <div class="box-container">

         <?php
            $select_products = $conn->prepare("SELECT * FROM `products` LIMIT 6");
            $select_products->execute();
            if($select_products->rowCount() > 0){
               while($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)){
         ?>
         <form action="" method="post" class="box">
            <input type="hidden" name="pid" value="<?= $fetch_products['id']; ?>">
            <input type="hidden" name="name" value="<?= htmlspecialchars($fetch_products['name']); ?>">
            <input type="hidden" name="price" value="<?= $fetch_products['price']; ?>">
            <input type="hidden" name="image" value="<?= htmlspecialchars($fetch_products['image']); ?>">
            <a href="quick_view.php?pid=<?= $fetch_products['id']; ?>" class="fas fa-eye" aria-label="Quick view <?= htmlspecialchars($fetch_products['name']); ?>"><span class="sr-only">Quick view <?= htmlspecialchars($fetch_products['name']); ?></span></a>
            <button type="submit" class="fas fa-shopping-cart" name="add_to_cart" aria-label="Add <?= htmlspecialchars($fetch_products['name']); ?> to cart"><span class="sr-only">Add to cart</span></button>
            <img src="uploaded_img/<?= htmlspecialchars($fetch_products['image']); ?>" alt="<?= htmlspecialchars($fetch_products['name']); ?>">
            <a href="category.php?category=<?= urlencode($fetch_products['category']); ?>" class="cat"><?= htmlspecialchars($fetch_products['category']); ?></a>
            <div class="name"><?= htmlspecialchars($fetch_products['name']); ?></div>
            <div class="flex">
               <div class="price"><span>₹</span><?= $fetch_products['price']; ?></div>
               <label class="sr-only" for="home-qty-<?= $fetch_products['id']; ?>">Quantity for <?= htmlspecialchars($fetch_products['name']); ?></label>
               <input type="number" id="home-qty-<?= $fetch_products['id']; ?>" name="qty" class="qty" min="1" max="99" value="1" maxlength="2" aria-label="Quantity for <?= htmlspecialchars($fetch_products['name']); ?>">
            </div>
         </form>
         <?php
               }
            }else{
               echo '<p class="empty" role="status">no products added yet!</p>';
            }
         ?>

      </div>

      <div class="more-btn">
         <a href="menu.php" class="btn">view all</a>
      </div>

   </section>

</main>

<?php include 'components/footer.php'; ?>

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

<script>

var swiper = new Swiper(".hero-slider", {
   loop:true,
   grabCursor: true,
   effect: "flip",
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
   },
});

</script>

</body>
</html>