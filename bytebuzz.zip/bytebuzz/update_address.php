<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:home.php');
   exit;
};

if(isset($_POST['submit'])){

   $address = $_POST['flat'] .', '.$_POST['building'].', '.$_POST['area'].', '.$_POST['town'] .', '. $_POST['city'] .', '. $_POST['state'] .', '. $_POST['country'] .' - '. $_POST['pin_code'];
   $address = filter_var($address, FILTER_SANITIZE_STRING);

   $update_address = $conn->prepare("UPDATE `users` set address = ? WHERE id = ?");
   $update_address->execute([$address, $user_id]);

   $message[] = 'address saved!';

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Update Delivery Address - ByteBuzz</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php' ?>

<main id="main-content">

   <h1 class="sr-only">Update Delivery Address</h1>

   <section class="form-container">

      <form action="" method="post" aria-labelledby="address-heading">
         <h2 id="address-heading" style="font-size:2.5rem; text-transform:uppercase; margin-bottom:1rem; color:var(--black);">your address</h2>
         
         <label for="addr-flat" class="sr-only">Flat Number</label>
         <input type="text" id="addr-flat" class="box" placeholder="flat no." required maxlength="50" name="flat" autocomplete="address-line1" aria-required="true">
         
         <label for="addr-building" class="sr-only">Building Number or Name</label>
         <input type="text" id="addr-building" class="box" placeholder="building no." required maxlength="50" name="building" autocomplete="address-line2" aria-required="true">
         
         <label for="addr-area" class="sr-only">Area or Locality Name</label>
         <input type="text" id="addr-area" class="box" placeholder="area name" required maxlength="50" name="area" autocomplete="address-level3" aria-required="true">
         
         <label for="addr-town" class="sr-only">Town</label>
         <input type="text" id="addr-town" class="box" placeholder="town name" required maxlength="50" name="town" aria-required="true">
         
         <label for="addr-city" class="sr-only">City</label>
         <input type="text" id="addr-city" class="box" placeholder="city name" required maxlength="50" name="city" autocomplete="address-level2" aria-required="true">
         
         <label for="addr-state" class="sr-only">State</label>
         <input type="text" id="addr-state" class="box" placeholder="state name" required maxlength="50" name="state" autocomplete="address-level1" aria-required="true">
         
         <label for="addr-country" class="sr-only">Country</label>
         <input type="text" id="addr-country" class="box" placeholder="country name" required maxlength="50" name="country" autocomplete="country-name" aria-required="true">
         
         <label for="addr-pin" class="sr-only">Postal PIN Code</label>
         <input type="number" id="addr-pin" class="box" placeholder="pin code" required max="999999" min="0" maxlength="6" name="pin_code" autocomplete="postal-code" aria-required="true">
         
         <input type="submit" value="save address" name="submit" class="btn">
      </form>

   </section>

</main>

<?php include 'components/footer.php' ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>