<?php
include 'components/connect.php';
session_start();

if (!isset($_SESSION['user_id'])) {
   header('location:home.php');
   exit;
}

$user_id = $_SESSION['user_id'];

// Get payment method + status from session (set in each payment file)
$method = $_SESSION['payment_method'] ?? 'Cash on Delivery';
$payment_status = $_SESSION['payment_status'] ?? 'pending';

// Fetch user details
$select_user = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
$select_user->execute([$user_id]);
$fetch_user = $select_user->fetch(PDO::FETCH_ASSOC);

$name = $fetch_user['name'] ?? '';
$number = $fetch_user['number'] ?? '';
$email = $fetch_user['email'] ?? '';
$address = $fetch_user['address'] ?? '';

// Get cart items
$select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
$select_cart->execute([$user_id]);

if ($select_cart->rowCount() > 0) {
   $total_products = '';
   $cart_total = 0;

   while ($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)) {
      $total_products .= $fetch_cart['name'] . ' (' . $fetch_cart['quantity'] . '), ';
      $cart_total += ($fetch_cart['price'] * $fetch_cart['quantity']);
   }

   // Insert into orders
   $insert_order = $conn->prepare("INSERT INTO `orders`
      (user_id, name, number, email, method, address, total_products, total_price, payment_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
   $insert_order->execute([
      $user_id,
      $name,
      $number,
      $email,
      $method,
      $address,
      $total_products,
      $cart_total,
      $payment_status
   ]);

   // Clear cart after order
   $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
   $delete_cart->execute([$user_id]);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Order Placed Successfully - ByteBuzz</title>
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <style>
      body {
         display: flex;
         justify-content: center;
         align-items: center;
         min-height: 100vh;
         background: #000;
         font-family: Arial, sans-serif;
         margin: 0;
         padding: 15px;
      }
      .success-box {
         text-align: center;
         background: #fff;
         padding: 40px;
         border-radius: 15px;
         box-shadow: 0 4px 12px rgba(0,0,0,0.2);
         max-width: 450px;
         width: 100%;
      }
      .success-box i {
         font-size: 60px;
         color: #b76e00;
         margin-bottom: 20px;
      }
      .success-box h1 {
         color: #000;
         margin-bottom: 10px;
         font-size: 26px;
      }
      .success-box p {
         color: #333;
         margin-bottom: 25px;
         font-size: 16px;
         line-height: 1.5;
      }
      .success-box a {
         display: inline-block;
         padding: 12px 24px;
         background: #ffc107;
         color: #000;
         font-weight: bold;
         text-decoration: none;
         border-radius: 8px;
         transition: 0.3s;
         font-size: 16px;
      }
      .success-box a:hover {
         background: #e0a800;
      }
      .success-box a:focus-visible {
         outline: 3px solid #000;
         outline-offset: 2px;
      }
   </style>
</head>
<body>
   <main class="success-box" role="status" aria-labelledby="order-success-heading">
      <i class="fas fa-check-circle" aria-hidden="true"></i>
      <h1 id="order-success-heading">Order Placed Successfully!</h1>
      <p>Thank you, <?= htmlspecialchars($name) ?>. Your order using <b><?= htmlspecialchars($method) ?></b> has been placed successfully.</p>
      <a href="orders.php" aria-label="View all your placed orders">View Orders</a>
   </main>
</body>
</html>
