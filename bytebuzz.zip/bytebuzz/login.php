<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['submit'])){

   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);

   $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ? AND password = ?");
   $select_user->execute([$email, $pass]);
   $row = $select_user->fetch(PDO::FETCH_ASSOC);

   if($select_user->rowCount() > 0){
      $_SESSION['user_id'] = $row['id'];
      header('location:home.php');
      exit;
   }else{
      $message[] = 'incorrect username or password!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login - ByteBuzz Account</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->
<?php include 'components/user_header.php'; ?>
<!-- header section ends -->

<main id="main-content">

   <h1 class="sr-only">User Login</h1>

   <section class="form-container">

      <form action="" method="post" aria-labelledby="login-heading">
         <h2 id="login-heading" style="font-size:2.5rem; text-transform:uppercase; margin-bottom:1rem; color:var(--black);">login now</h2>
         
         <label for="login-email" class="sr-only">Email Address</label>
         <input type="email" id="login-email" name="email" required placeholder="enter your email" class="box" maxlength="50" autocomplete="email username" aria-required="true" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <label for="login-password" class="sr-only">Password</label>
         <input type="password" id="login-password" name="pass" required placeholder="enter your password" class="box" maxlength="50" autocomplete="current-password" aria-required="true" oninput="this.value = this.value.replace(/\s/g, '')">
         
         <input type="submit" value="login now" name="submit" class="btn">
         <p>don't have an account? <a href="register.php">register now</a></p>
      </form>

   </section>

</main>

<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>