<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/add_cart.php';

$category = $_GET['category'] ?? '';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title><?= htmlspecialchars($category); ?> - ByteBuzz Menu Category</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<main id="main-content">

   <div class="heading" aria-label="Breadcrumb">
      <h2>FOOD CATEGORY</h2>
      <p><a href="home.php">HOME</a> <a href="menu.php">/ MENU</a> <span aria-current="page"> / <?= htmlspecialchars($category); ?></span></p>
   </div>

   <section class="products" aria-labelledby="category-title">

      <h1 class="title" id="category-title"><?= htmlspecialchars($category); ?></h1>

      <div class="box-container">

         <?php
            $select_products = $conn->prepare("SELECT * FROM `products` WHERE category = ?");
            $select_products->execute([$category]);
            if($select_products->rowCount() > 0){
               while($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)){
         ?>
         <form action="" method="post" class="box">
            <input type="hidden" name="pid" value="<?= $fetch_products['id']; ?>">
            <input type="hidden" name="name" value="<?= htmlspecialchars($fetch_products['name']); ?>">
            <input type="hidden" name="price" value="<?= $fetch_products['price']; ?>">
            <input type="hidden" name="image" value="<?= htmlspecialchars($fetch_products['image']); ?>">
            <a href="quick_view.php?pid=<?= $fetch_products['id']; ?>" class="fas fa-eye" aria-label="Quick view <?= htmlspecialchars($fetch_products['name']); ?>"><span class="sr-only">Quick view <?= htmlspecialchars($fetch_products['name']); ?></span></a>
            <button type="submit" class="fas fa-shopping-cart" name="add_to_cart" aria-label="Add <?= htmlspecialchars($fetch_products['name']); ?> to cart"><span class="sr-only">Add to cart</span></button>
            <img src="uploaded_img/<?= htmlspecialchars($fetch_products['image']); ?>" alt="<?= htmlspecialchars($fetch_products['name']); ?>">
            <div class="name"><?= htmlspecialchars($fetch_products['name']); ?></div>
            <div class="flex">
               <div class="price"><span>₹</span><?= $fetch_products['price']; ?></div>
               <label class="sr-only" for="cat-qty-<?= $fetch_products['id']; ?>">Quantity for <?= htmlspecialchars($fetch_products['name']); ?></label>
               <input type="number" id="cat-qty-<?= $fetch_products['id']; ?>" name="qty" class="qty" min="1" max="99" value="1" maxlength="2" aria-label="Quantity for <?= htmlspecialchars($fetch_products['name']); ?>">
            </div>
         </form>
         <?php
               }
            }else{
               echo '<p class="empty" role="status">no products added in this category yet!</p>';
            }
         ?>

      </div>

   </section>

</main>

<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>