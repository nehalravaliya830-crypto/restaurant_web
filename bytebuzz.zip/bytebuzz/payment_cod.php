<?php
session_start();
$_SESSION['payment_method'] = "COD";
$_SESSION['payment_status'] = "pending";

if(isset($_POST['pay_cod'])){
   header("Location: success.php");
   exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Cash on Delivery - ByteBuzz Checkout</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <style>
      body{display:flex;justify-content:center;align-items:center;min-height:100vh;background:#000;font-family:Arial, sans-serif;margin:0;padding:15px;}
      .payment-box{background:#fff;padding:40px;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,0.2);width:100%;max-width:500px;text-align:center;}
      .payment-box h1{margin-bottom:20px;color:#000;font-size:24px;}
      .payment-box p{color:#333;margin-bottom:20px;font-size:16px;}
      .status{color:#c0392b;font-weight:bold;margin-bottom:20px;}
      .btn{width:100%;padding:14px;background:#fbc02d;color:#000;font-weight:bold;border:none;border-radius:8px;cursor:pointer;transition:0.3s;font-size:16px;}
      .btn:hover{background:#e6ac00;}
      .btn:focus-visible{outline:3px solid #000;outline-offset:2px;}
      .skip-link{position:absolute;top:-100px;left:15px;background:#fff;color:#000;padding:10px 15px;font-weight:bold;text-decoration:none;z-index:100;}
      .skip-link:focus{top:15px;outline:3px solid #fbc02d;}
   </style>
</head>
<body>
   <a href="#payment-main" class="skip-link">Skip to payment</a>
   <main id="payment-main" class="payment-box">
      <h1><i class="fas fa-hand-holding-usd" aria-hidden="true"></i> Cash on Delivery</h1>
      <p>You will pay in cash at the time of delivery.</p>
      <p class="status">Payment Status: <?php echo htmlspecialchars($_SESSION['payment_status']); ?></p>
      <form method="post">
         <input type="submit" name="pay_cod" value="Confirm Order" class="btn" aria-label="Confirm cash on delivery order">
      </form>
   </main>
</body>
</html>
