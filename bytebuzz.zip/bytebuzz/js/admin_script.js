const profile = document.querySelector('.header .flex .profile');
const navbar = document.querySelector('.header .flex .navbar');
const userBtn = document.querySelector('#user-btn');
const menuBtn = document.querySelector('#menu-btn');

function toggleAdminProfile(forceClose = false) {
   if (!profile) return;
   const isActive = forceClose ? false : !profile.classList.contains('active');
   profile.classList.toggle('active', isActive);
   if (userBtn) {
      userBtn.setAttribute('aria-expanded', isActive ? 'true' : 'false');
   }
   if (isActive && navbar) {
      toggleAdminMenu(true);
   }
}

function toggleAdminMenu(forceClose = false) {
   if (!navbar) return;
   const isActive = forceClose ? false : !navbar.classList.contains('active');
   navbar.classList.toggle('active', isActive);
   if (menuBtn) {
      menuBtn.setAttribute('aria-expanded', isActive ? 'true' : 'false');
   }
   if (isActive && profile) {
      toggleAdminProfile(true);
   }
}

if (userBtn) {
   userBtn.onclick = () => toggleAdminProfile();
   userBtn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
         e.preventDefault();
         toggleAdminProfile();
      }
   });
}

if (menuBtn) {
   menuBtn.onclick = () => toggleAdminMenu();
   menuBtn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
         e.preventDefault();
         toggleAdminMenu();
      }
   });
}

// Escape key closes menus
window.addEventListener('keydown', (e) => {
   if (e.key === 'Escape') {
      if (profile && profile.classList.contains('active')) {
         toggleAdminProfile(true);
         if (userBtn) userBtn.focus();
      }
      if (navbar && navbar.classList.contains('active')) {
         toggleAdminMenu(true);
         if (menuBtn) menuBtn.focus();
      }
   }
});

window.onscroll = () => {
   if (profile && profile.classList.contains('active')) toggleAdminProfile(true);
   if (navbar && navbar.classList.contains('active')) toggleAdminMenu(true);
};

// Accessible close for notification messages
document.querySelectorAll('.message .fa-times').forEach(closeBtn => {
   closeBtn.setAttribute('role', 'button');
   closeBtn.setAttribute('tabindex', '0');
   closeBtn.setAttribute('aria-label', 'Close notification');
   closeBtn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
         e.preventDefault();
         closeBtn.parentElement.remove();
      }
   });
});

// Image gallery preview accessibility in update product
const subImages = document.querySelectorAll('.update-product .image-container .sub-images img');
const mainImage = document.querySelector('.update-product .image-container .main-image img');

if (subImages.length > 0 && mainImage) {
   subImages.forEach((image, index) => {
      image.setAttribute('tabindex', '0');
      image.setAttribute('role', 'button');
      image.setAttribute('aria-label', 'Preview image ' + (index + 1));
      const switchImg = () => {
         const src = image.getAttribute('src');
         mainImage.src = src;
      };
      image.onclick = switchImg;
      image.addEventListener('keydown', (e) => {
         if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            switchImg();
         }
      });
   });
}