const navbar = document.querySelector('.header .flex .navbar');
const profile = document.querySelector('.header .flex .profile');
const menuBtn = document.querySelector('#menu-btn');
const userBtn = document.querySelector('#user-btn');

function toggleMenu(forceClose = false) {
   if (!navbar) return;
   const isActive = forceClose ? false : !navbar.classList.contains('active');
   navbar.classList.toggle('active', isActive);
   if (menuBtn) {
      menuBtn.setAttribute('aria-expanded', isActive ? 'true' : 'false');
   }
   if (isActive && profile) {
      toggleProfile(true);
   }
}

function toggleProfile(forceClose = false) {
   if (!profile) return;
   const isActive = forceClose ? false : !profile.classList.contains('active');
   profile.classList.toggle('active', isActive);
   if (userBtn) {
      userBtn.setAttribute('aria-expanded', isActive ? 'true' : 'false');
   }
   if (isActive && navbar) {
      toggleMenu(true);
   }
}

if (menuBtn) {
   menuBtn.onclick = () => toggleMenu();
   menuBtn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
         e.preventDefault();
         toggleMenu();
      }
   });
}

if (userBtn) {
   userBtn.onclick = () => toggleProfile();
   userBtn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
         e.preventDefault();
         toggleProfile();
      }
   });
}

// Close on escape key and return focus
window.addEventListener('keydown', (e) => {
   if (e.key === 'Escape') {
      if (profile && profile.classList.contains('active')) {
         toggleProfile(true);
         if (userBtn) userBtn.focus();
      }
      if (navbar && navbar.classList.contains('active')) {
         toggleMenu(true);
         if (menuBtn) menuBtn.focus();
      }
   }
});

// Close dropdowns on scroll
window.onscroll = () => {
   if (navbar && navbar.classList.contains('active')) toggleMenu(true);
   if (profile && profile.classList.contains('active')) toggleProfile(true);
};

// Accessible message notification close handling
document.querySelectorAll('.message .fa-times').forEach(closeBtn => {
   closeBtn.setAttribute('role', 'button');
   closeBtn.setAttribute('tabindex', '0');
   closeBtn.setAttribute('aria-label', 'Close notification');
   closeBtn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
         e.preventDefault();
         closeBtn.parentElement.remove();
      }
   });
});

// Screen reader announce container helper
function announceLiveMessage(text, priority = 'polite') {
   let announcer = document.getElementById('a11y-live-announcer');
   if (!announcer) {
      announcer = document.createElement('div');
      announcer.id = 'a11y-live-announcer';
      announcer.className = 'sr-only';
      announcer.setAttribute('aria-live', priority);
      announcer.setAttribute('aria-atomic', 'true');
      document.body.appendChild(announcer);
   }
   announcer.textContent = '';
   setTimeout(() => { announcer.textContent = text; }, 50);
}

// Accessible Loader handling with reduced-motion support
function hideLoader() {
   const loaderElem = document.querySelector('.loader');
   if (loaderElem) {
      loaderElem.style.display = 'none';
      loaderElem.setAttribute('aria-hidden', 'true');
   }
}

if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
   hideLoader();
} else {
   window.addEventListener('load', () => {
      setTimeout(hideLoader, 600);
   });
}

// Number input length limiter
document.querySelectorAll('input[type="number"]').forEach(numberInput => {
   numberInput.oninput = () => {
      if (numberInput.value.length > numberInput.maxLength) {
         numberInput.value = numberInput.value.slice(0, numberInput.maxLength);
      }
   };
});