<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:home.php');
   exit;
};

// Ensure profile details are loaded
$select_profile = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
$select_profile->execute([$user_id]);
$fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['submit'])){

   $method = $_POST['method'];

   // Redirect based on selected payment method
   if($method == "cash on delivery"){
      header("Location: payment_cod.php");
      exit;
   } elseif($method == "credit card"){
      header("Location: payment_credit.php");
      exit;
   } elseif($method == "debit card"){
      header("Location: payment_debit.php");
      exit;
   } elseif($method == "paytm"){
      header("Location: payment_paytm.php");
      exit;
   } elseif($method == "paypal"){
      header("Location: payment_paypal.php");
      exit;
   }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Checkout - Complete Your Order | ByteBuzz</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->
<?php include 'components/user_header.php'; ?>
<!-- header section ends -->

<main id="main-content">

   <div class="heading" aria-label="Breadcrumb">
      <h2>checkout</h2>
      <p><a href="home.php">HOME</a> <span aria-current="page"> / checkout</span></p>
   </div>

   <section class="checkout" aria-labelledby="checkout-summary-title">

      <h1 class="title" id="checkout-summary-title">Order Summary</h1>

   <form action="" method="post">

      <div class="cart-items" aria-label="Selected cart items">
         <h3>cart items</h3>
         <?php
            $grand_total = 0;
            $cart_items = [];
            $total_products = '';
            $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
            $select_cart->execute([$user_id]);
            if($select_cart->rowCount() > 0){
               while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
                  $cart_items[] = $fetch_cart['name'].' ('.$fetch_cart['price'].' x '. $fetch_cart['quantity'].') - ';
                  $total_products = implode('', $cart_items);
                  $grand_total += ($fetch_cart['price'] * $fetch_cart['quantity']);
         ?>
         <p><span class="name"><?= htmlspecialchars($fetch_cart['name']); ?></span><span class="price">₹<?= $fetch_cart['price']; ?> x <?= $fetch_cart['quantity']; ?></span></p>
         <?php
               }
            }else{
               echo '<p class="empty" role="status">your cart is empty!</p>';
            }
         ?>
         <p class="grand-total"><span class="name">grand total :</span><span class="price">₹<?= $grand_total; ?></span></p>
         <a href="cart.php" class="btn" aria-label="View and edit cart items">view cart</a>
      </div>

      <input type="hidden" name="total_products" value="<?= htmlspecialchars($total_products); ?>">
      <input type="hidden" name="total_price" value="<?= $grand_total; ?>">
      <input type="hidden" name="name" value="<?= htmlspecialchars($fetch_profile['name'] ?? '') ?>">
      <input type="hidden" name="number" value="<?= htmlspecialchars($fetch_profile['number'] ?? '') ?>">
      <input type="hidden" name="email" value="<?= htmlspecialchars($fetch_profile['email'] ?? '') ?>">
      <input type="hidden" name="address" value="<?= htmlspecialchars($fetch_profile['address'] ?? '') ?>">

      <div class="user-info">
         <h3>your info</h3>
         <p><i class="fas fa-user" aria-hidden="true"></i><span><?= htmlspecialchars($fetch_profile['name'] ?? '') ?></span></p>
         <p><i class="fas fa-phone" aria-hidden="true"></i><span><?= htmlspecialchars($fetch_profile['number'] ?? '') ?></span></p>
         <p><i class="fas fa-envelope" aria-hidden="true"></i><span><?= htmlspecialchars($fetch_profile['email'] ?? '') ?></span></p>
         <a href="update_profile.php" class="btn" aria-label="Update contact information">update info</a>
         <h3>delivery address</h3>
         <p><i class="fas fa-map-marker-alt" aria-hidden="true"></i><span><?php if(empty($fetch_profile['address'])){echo 'please enter your address';}else{echo htmlspecialchars($fetch_profile['address']);} ?></span></p>
         <a href="update_address.php" class="btn" aria-label="Update delivery address">update address</a>
         
         <label for="payment-method" class="sr-only">Select Payment Method</label>
         <select id="payment-method" name="method" class="box" required aria-required="true">
            <option value="" disabled selected>select payment method --</option>
            <option value="cash on delivery">Cash on Delivery</option>
            <option value="credit card">Credit Card</option>
            <option value="debit card">Debit Card</option>
            <option value="paytm">Paytm</option>
            <option value="paypal">PayPal</option>
         </select>

         <input type="submit" value="place order" 
            class="btn <?php if(empty($fetch_profile['address'])){echo 'disabled';} ?>" 
            style="width:100%; background:var(--red); color:var(--white);" 
            name="submit"
            <?= empty($fetch_profile['address']) ? 'aria-disabled="true"' : ''; ?>>
      </div>

   </form>
      
   </section>

</main>

<!-- footer section starts  -->
<?php include 'components/footer.php'; ?>
<!-- footer section ends -->

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>