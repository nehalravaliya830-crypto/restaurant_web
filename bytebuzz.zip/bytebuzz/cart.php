<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:home.php');
};

if(isset($_POST['delete'])){
   $cart_id = $_POST['cart_id'];
   $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE id = ?");
   $delete_cart_item->execute([$cart_id]);
   $message[] = 'cart item deleted!';
}

if(isset($_POST['delete_all'])){
   $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
   $delete_cart_item->execute([$user_id]);
   // header('location:cart.php');
   $message[] = 'deleted all from cart!';
}

if(isset($_POST['update_qty'])){
   $cart_id = $_POST['cart_id'];
   $qty = $_POST['qty'];
   $qty = filter_var($qty, FILTER_SANITIZE_STRING);
   $update_qty = $conn->prepare("UPDATE `cart` SET quantity = ? WHERE id = ?");
   $update_qty->execute([$qty, $cart_id]);
   $message[] = 'cart quantity updated';
}

$grand_total = 0;

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Your Shopping Cart - ByteBuzz</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->
<?php include 'components/user_header.php'; ?>
<!-- header section ends -->

<main id="main-content">

   <div class="heading" aria-label="Breadcrumb">
      <h2>shopping cart</h2>
      <p><a href="home.php">HOME</a> <span aria-current="page"> / cart</span></p>
   </div>

   <!-- shopping cart section starts  -->

   <section class="products" aria-labelledby="cart-title">

      <h1 class="title" id="cart-title">Your cart</h1>

      <div class="box-container">

         <?php
            $grand_total = 0;
            $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
            $select_cart->execute([$user_id]);
            if($select_cart->rowCount() > 0){
               while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
         ?>
         <form action="" method="post" class="box">
            <input type="hidden" name="cart_id" value="<?= $fetch_cart['id']; ?>">
            <a href="quick_view.php?pid=<?= $fetch_cart['pid']; ?>" class="fas fa-eye" aria-label="Quick view <?= htmlspecialchars($fetch_cart['name']); ?>"><span class="sr-only">Quick view <?= htmlspecialchars($fetch_cart['name']); ?></span></a>
            <button type="submit" class="fas fa-times" name="delete" onclick="return confirm('delete this item?');" aria-label="Remove <?= htmlspecialchars($fetch_cart['name']); ?> from cart"><span class="sr-only">Remove item</span></button>
            <img src="uploaded_img/<?= htmlspecialchars($fetch_cart['image']); ?>" alt="<?= htmlspecialchars($fetch_cart['name']); ?>">
            <div class="name"><?= htmlspecialchars($fetch_cart['name']); ?></div>
            <div class="flex">
               <div class="price"><span>₹</span><?= $fetch_cart['price']; ?></div>
               <label class="sr-only" for="cart-qty-<?= $fetch_cart['id']; ?>">Quantity for <?= htmlspecialchars($fetch_cart['name']); ?></label>
               <input type="number" id="cart-qty-<?= $fetch_cart['id']; ?>" name="qty" class="qty" min="1" max="99" value="<?= $fetch_cart['quantity']; ?>" maxlength="2" aria-label="Quantity for <?= htmlspecialchars($fetch_cart['name']); ?>">
               <button type="submit" class="fas fa-edit" name="update_qty" aria-label="Update quantity for <?= htmlspecialchars($fetch_cart['name']); ?>"><span class="sr-only">Update quantity</span></button>
            </div>
            <div class="sub-total"> sub total : <span>₹<?= $sub_total = ($fetch_cart['price'] * $fetch_cart['quantity']); ?>/-</span> </div>
         </form>
         <?php
                  $grand_total += $sub_total;
               }
            }else{
               echo '<p class="empty" role="status">your cart is empty</p>';
            }
         ?>

      </div>

      <div class="cart-total">
         <p>cart total : <span>₹<?= $grand_total; ?></span></p>
         <a href="checkout.php" class="btn <?= ($grand_total > 1)?'':'disabled'; ?>" <?= ($grand_total <= 1)?'aria-disabled="true"':''; ?>>proceed to checkout</a>
      </div>

      <div class="more-btn">
         <form action="" method="post">
            <button type="submit" class="delete-btn <?= ($grand_total > 1)?'':'disabled'; ?>" name="delete_all" onclick="return confirm('delete all from cart?');" <?= ($grand_total <= 1)?'aria-disabled="true"':''; ?>>delete all</button>
         </form>
         <a href="menu.php" class="btn">continue ordering</a>
      </div>

   </section>

   <!-- shopping cart section ends -->

</main>

<!-- footer section starts  -->
<?php include 'components/footer.php'; ?>
<!-- footer section ends -->

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>